function ukm() {
  document.getElementById("demo1").innerHTML = "Become teacher";
}
